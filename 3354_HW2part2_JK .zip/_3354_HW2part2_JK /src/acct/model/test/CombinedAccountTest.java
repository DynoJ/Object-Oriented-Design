package acct.model.test;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import acct.model.AccountList;
import acct.model.Account;
import java.math.BigDecimal;

public class CombinedAccountTest {
    private AccountList accountList;
    private Account account;

    @Before
    public void setUp() {
        accountList = new AccountList();
        account = new Account("123", "Test Account", new BigDecimal("1000.00"));
        accountList.addAccount(account);
    }

    @Test
    public void testAddAccount() {
        assertEquals("Account should be added to the list",
                account, accountList.getAccount("123"));
    }

    @Test
    public void testRemoveAccount() {
        accountList.removeAccount("123");
        assertNull("Account should be removed from the list",
                accountList.getAccount("123"));
    }
}
