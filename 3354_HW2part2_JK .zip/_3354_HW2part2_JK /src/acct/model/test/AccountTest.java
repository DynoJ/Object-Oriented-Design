package acct.model.test;

import org.junit.Test;
import static org.junit.Assert.*;
import java.math.BigDecimal;
import acct.model.Account.OverdrawException;
import acct.model.Account;

public class AccountTest {

    @Test
    public void testDeposit() {
        Account account = new Account("1", "Test Account", BigDecimal.ZERO);
        account.deposit(new BigDecimal("100.00"));
        assertEquals(0, account.getBalance().compareTo(new BigDecimal("100.00")));
    }

    @Test
    public void testWithdraw() throws OverdrawException {
        Account account = new Account("1", "Test Account", new BigDecimal("100.00"));
        account.withdraw(new BigDecimal("50.00"));
        assertEquals(0, account.getBalance().compareTo(new BigDecimal("50.00")));
    }

    @Test(expected = OverdrawException.class)
    public void testOverdraw() throws OverdrawException {
        Account account = new Account("1", "Test Account", new BigDecimal("50.00"));
        account.withdraw(new BigDecimal("100.00"));
    }

}
