package acct.model.test;

import acct.model.Account;
import acct.model.AccountList;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import java.math.BigDecimal;

public class AccountListTest {
    private AccountList accountList;
    private Account account;

    @Before
    public void setUp() {
        // Setup is run before each test case
        accountList = new AccountList();
        account = new Account("123", "Test Account", new BigDecimal("1000.00"));
        accountList.addAccount(account);
    }

    @Test
    public void testAddAccount() {
        // Assuming AccountList has a method 'getAccount' to retrieve an account by ID
        Account retrieved = accountList.getAccount(account.getId());
        assertNotNull("Account should be found in the list", retrieved);
        assertEquals("Retrieved account should be the same as the one added", account, retrieved);
    }

    @Test
    public void testRemoveAccount() {
        accountList.removeAccount(account.getId());
        Account retrieved = accountList.getAccount(account.getId());
        assertNull("Account should be removed from the list", retrieved);
    }

}
