/*
Author: Jack Kammerer netID: ulp1
Date:2/15/24
 */
package binTree;
/**
 * Creating a binary tree
 */
public class BinTree {
    private Node root = null;
    /**
     * Inserts a value into the binary search
     * tree
     * @param val returns the inserted node
     * @return root
     */
    public Node insertNode(int val)
    {
        root = insertNodeRec(root, val);
        return root;
    }
    /**
     * Recursive helper method
     *
     * @param current subtree rooted
     * @param val into subtree
     * @return current
     */
    private Node insertNodeRec(Node current, int val)
    {
        if (current == null)
        {
            return new Node(val);
        }
        if (val < current.val)
        {
            current.leftChild = insertNodeRec(current.leftChild, val);
        }
        else if (val > current.val)
        {
            current.rightChild = insertNodeRec(current.rightChild, val);
        }
        return current;
    }
    /**
     * Triggers an in-order traversal of the
     * binary search tree
     */
    public void treeWalk()
    {
        inOrderRec(root);
    }
    /**
     * Recursively
     * @param node performs an in-order
     *             traversal of the tree
     */
    private void inOrderRec(Node node)
    {
        if (node != null)
        {
            inOrderRec(node.leftChild);
            System.out.println(node.val);
            inOrderRec(node.rightChild);
        }
    }
    /**
     * Inner class to define the structure
     * of each node in the binary search
     * tree
     */
    private class Node
    {
        private int val = 0;

        public Node leftChild = null;
        public Node rightChild = null;
        /**
         * @param val then constructs a Node
         */
        public Node(int val)
        {
            this.val = val;
        }
    }
}

