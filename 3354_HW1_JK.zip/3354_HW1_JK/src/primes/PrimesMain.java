package primes;
/*
Author: Jack Kammerer netID: ulp1
Date:2/15/24
 */
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;

public class PrimesMain {
    public static void main(String[] args)
    {
        if (args.length != 2)
        {
            System.out.println("Usage: java PrimesMain <upper-bound> <filename>");
            return;
        }
            int N = Integer.parseInt(args[0]);
            String filename = args[1];

            boolean[] isPrime = new boolean[N + 1];
            Arrays.fill(isPrime, true);
            isPrime[0] = false;
            isPrime[1] = false;

            for (int i = 2; i * i <= N; i++)
            {
                if (isPrime[i])
                {
                    for (int j = i * i; j <= N; j += i)
                    {
                        isPrime[j] = false;
                    }
                }
            }
            try (FileWriter outFile = new FileWriter(filename))
            {
                for (int i = 2; i <= N; i++)
                {
                    if (isPrime[i])
                    {
                        outFile.write(i + System.lineSeparator());
                    }
                }
            }
            catch (IOException e)
            {
                System.out.println("An error occurred while writing to the file: " + e.getMessage());
            }
    }
}
