package acct.model;

public enum AgentStatus {
    Running, Blocked, Paused, NA
}
