package acct.model;

import java.util.HashMap;
import java.util.Map;

public class AccountList {
    private Map<String, Account> accounts = new HashMap<>();

    // Add account
    public void addAccount(Account account) {
        accounts.put(account.getId(), account);
    }
    public Account getAccount(String id) {
        return accounts.get(id);
    }

    // Remove account
    public void removeAccount(String accountId) {
        accounts.remove(accountId);
    }

}
