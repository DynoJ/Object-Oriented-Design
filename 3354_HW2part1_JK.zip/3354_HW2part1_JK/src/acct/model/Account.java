package acct.model;
import java.math.BigDecimal;

public class Account extends AbstractModel {
    private BigDecimal balance;
    private String name;
    private String id;

    // Constructor
    public Account(String id, String name, BigDecimal balance) {
        this.id = id;
        this.name = name;
        this.balance = balance;
    }

    // Withdraw method
    public void withdraw(BigDecimal amount) throws OverdrawException {
        if (balance.compareTo(amount) < 0) {
            throw new OverdrawException("Insufficient funds");
        }
        balance = balance.subtract(amount);
        notifyListeners(new ModelEvent(ModelEvent.EventKind.BalanceUpdate, balance));
    }

    // Deposit method
    public void deposit(BigDecimal amount) {
        balance = balance.add(amount);
        notifyListeners(new ModelEvent(ModelEvent.EventKind.BalanceUpdate, balance));
    }

    // Getters and setters
    public BigDecimal getBalance() {
        return balance;
    }
    public String getName() {
        return name;
    }
    public String getId() {
        return id;
    }
    protected void notifyListeners(ModelEvent event) {
        // Logic to notify all registered listeners about the event
        // This typically involves looping over a collection of listener objects
        // and calling a method on them to inform them of the event
    }
    // ModelEvent class
    public static class ModelEvent {
        // Enum to describe the kind of event
        public enum EventKind {
            BalanceUpdate, // When a deposit or withdrawal is made
            // ... other event kinds
        }

        private EventKind kind;
        private BigDecimal balance;

        public ModelEvent(EventKind kind, BigDecimal balance) {
            this.kind = kind;
            this.balance = balance;
        }
        // Getters for event properties
        public EventKind getKind() {
            return kind;
        }
        public BigDecimal getBalance() {
            return balance;
        }
    }
    public static class OverdrawException extends Exception {
        public OverdrawException(String message) {
            super(message);
        }
    }
}
