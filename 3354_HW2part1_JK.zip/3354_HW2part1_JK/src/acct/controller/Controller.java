package acct.controller;

import acct.view.View;
import acct.model.Model;

public interface Controller {
    void setModel(Model model);
    Model getModel();
    View getView();
    void setView(View view);
}
