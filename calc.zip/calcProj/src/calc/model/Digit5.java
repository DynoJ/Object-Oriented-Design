package calc.model;

public class Digit5 extends Exception {
	public Digit5() { super(); }
	public Digit5(String s) { super(s); }
}
